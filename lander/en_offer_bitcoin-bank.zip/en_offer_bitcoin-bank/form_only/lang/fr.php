<?php
$text = new stdClass();

$text->first_name = 'Prénom';
$text->last_name = 'Nom de famille';
$text->full_name = 'Nom complet';

$text->email = 'E-mail';
$text->phone = 'Numéro de téléphone';
$text->register = 'Inscrivez-vous ici';
$text->terms = 'Termes et conditions';

$text->thanks = 'Merci pour votre inscription';
$text->redirect = 'Vous êtes redirigé vers le courtier';

$text->end = "Pour investir, vous devez avoir au moins 18 ans. Capital minimum requis : 250 $";

$text->email_exist = "Un client avec cette adresse e-mail existe déjà.";
$text->phone_exist = "Un client avec ce numéro de téléphone existe déjà.";
$text->general = "Erreur, veuillez réessayer plus tard.";

$text->terms = "En m'inscrivant, j'accepte";
$text->terms2 = "les conditions d'utilisation";
$text->terms3 = "la politique de confidentialité";