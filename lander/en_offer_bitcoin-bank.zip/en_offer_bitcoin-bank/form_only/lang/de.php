<?php
$text = new stdClass();


$text->first_name = 'Vorname';
$text->last_name = 'Nachname';
$text->full_name = 'Vollständiger Name';

$text->email = 'E-Mail';
$text->phone = 'Telefonnummer';
$text->register = 'Hier registrieren';
$text->terms = 'Allgemeine Geschäftsbedingungen';


$text->thanks ='Danke für die Registrierung';
$text->redirect ='Sie leiten zum Broker weiter';

$text->end = "Um zu investieren, müssen Sie mindestens 18 Jahre alt sein. Mindestkapital erforderlich: 250 $";

$text->email_exist = "Customer with this email already exists.";
$text->phone_exist = "Customer with this phone number already exists.";
$text->general = "Error, Please try again later";

$text->terms = "Durch die Registrierung stimme ich zu";
$text->terms2 = "den Nutzungsbedingungen";
$text->terms3 = "der Datenschutzrichtlinie";