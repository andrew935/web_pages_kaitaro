<?php
$text = new stdClass();

$text->first_name = 'Nome';
$text->last_name = 'Sobrenome';
$text->full_name = 'Nome Completo';

$text->email = 'E-mail';
$text->phone = 'Número de telefone';
$text->register = 'REGISTRE-SE AQUI';
$text->terms = 'Termos e condições';


$text->thanks ='Obrigado por se registrar';
$text->redirect ='Você está redirecionando para o Broker';
$text->end = "Para investir você deve ter pelo menos 18 anos de idade. Capital mínimo exigido $250";

$text->email_exist = "Já existe um cliente com este e-mail.";
$text->phone_exist = "Já existe um cliente com este número de telefone.";
$text->general = "Erro, tente novamente mais tarde";

$text->terms = "Eu concordo com e";
$text->terms2 = " política deprivacidade ";
$text->terms3 = "termos e condições";
