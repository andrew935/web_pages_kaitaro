<?php
$text = new stdClass();

$text->first_name = '名';
$text->last_name = '姓';
$text->full_name = '氏名';

$text->email = 'メール';
$text->phone = '電話番号';
$text->register = '登録はこちら';
$text->terms = '利用規約';

$text-> thanks ='ご登録ありがとうございます';
$text->redirect ='ブローカーにリダイレクトしています';


$text->end = "投資するには、18 歳以上である必要があります。最低資本金は $250";


$text->email_exist = "このメールアドレスを持つ顧客はすでに存在します。";
$text->errors->phone_exist = "この電話番号を持つ顧客はすでに存在します。";
$text->errors->general = "エラー。後でもう一度お試しください。";

$text->terms = "登録することで、同意します";
$text->terms2 = "利用規約";
$text->terms3 = "プライバシーポリシー";