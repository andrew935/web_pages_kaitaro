<?php
$text = new stdClass();

$text->first_name = '이름';
$text->last_name = '성';
$text->full_name = '전체 이름';

$text->email = '이메일';
$text->phone = '전화번호';
$text->register = '여기에 등록하세요';
$text->terms = '약관';


$text->thanks ='등록해주셔서 감사합니다';
$text->redirect ='브로커로 리디렉션 중입니다.';

$text->end = "투자하려면 최소 18세 이상이어야 합니다. 최소 자본금 $250 필요";

$text->email_exist = "이 이메일을 받은 고객은 이미 존재합니다.";
$text->phone_exist = "이 전화번호를 사용하는 고객이 이미 존재합니다.";
$text->general = "오류가 발생했습니다. 나중에 다시 시도하십시오";

$text->terms = "등록함으로써 동의합니다";
$text->terms2 = "이용 약관";
$text->terms3 = "개인정보 처리방침";
