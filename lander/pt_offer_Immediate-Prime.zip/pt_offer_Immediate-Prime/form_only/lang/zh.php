<?php
$text = new stdClass();

$text->first_name = '名';
$text->last_name = '姓';
$text->full_name = '全名';

$text->email = '電子郵件';
$text->phone = '電話號碼r';
$text->register = '在這裡註冊';
$text->terms = '條款和條件';


$text->thanks ='感謝您的註冊';
$text->redirect ='你正在重定向到 Broker';

$text->end = "要投資，您必須年滿 18 歲。最低資本要求 $250";

$text->email_exist = "使用此電子郵件地址的客戶已存在。";
$text->phone_exist = "使用此電話號碼的客戶已存在。";
$text->general = "錯誤，請稍後重試";

$text->terms = "注册即表示我同意";
$text->terms2 = "使用条款";
$text->terms3 = "隐私政策";


