<?php
$text = new stdClass();

$text->first_name = 'First name';
$text->last_name = 'Last Name';
$text->full_name = 'Full Name';

$text->email = 'Email';
$text->phone = 'Phone number';
$text->register = 'Register Here';
$text->terms = 'Terms and conditions';


$text->thanks ='Thank you for registration';
$text->redirect ='You are being redirected to the broker';

$text->end = "To invest you must be at least 18 years of age. Minimum capital required $250";

$text->email_exist = "Customer with this email already exists.";
$text->phone_exist = "Customer with this phone number already exists.";
$text->general = "Error, Please try again later";


$text->terms = "By registering, I agree to the website's";
$text->terms2 = "terms of use";
$text->terms3 = "privacy policy";