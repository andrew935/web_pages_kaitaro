<?php
$text = new stdClass();

$text->first_name = 'Nombre';
$text->last_name = 'Apellido';
$text->full_name = 'Nombre completo';

$text->email = 'Correo electrónico';
$text->phone = 'Número de teléfono';
$text->register = 'Regístrese aquí';
$text->terms = 'Términos y condiciones';



$text->thanks ='Gracias por registrarse';
$text->redirect ='Está redirigiendo a Broker';

$text->end = "Para invertir debe tener al menos 18 años de edad. Capital mínimo requerido $250";

$text->email_exist = "El cliente con este correo electrónico ya existe";
$text->phone_exist = "El cliente con este número de teléfono ya existe";
$text->general = "Error, inténtelo de nuevo más tarde";

$text->terms = "Estoy de acuerdo con la";
$text->terms2 = "política de privacidad";
$text->terms3 = "términos y condiciones";

